# DISCOVERY-QA-001 independent evaluator instructions

Use only files in this evaluator bundle. Do not inspect Tender Agent code, prompts,
weights, scores, SUT output, previous benchmark labels, network or web sources.

For every case in `cohort_evaluator_index.json`, judge whether the procurement is
relevant to the frozen supplier profile and query context in that case's
`evaluator_bundle.json`.

Allowed labels:
- `RELEVANT`: clear fit for the supplier's goods/capabilities.
- `PARTIALLY_RELEVANT`: meaningful fit exists, but the procurement is mixed,
  peripheral, or material scope uncertainty remains.
- `IRRELEVANT`: source evidence shows the procurement is outside supplier scope.
- `UNCLEAR`: bundled public-source evidence is insufficient to decide safely.

Every non-UNCLEAR label must cite at least one evidence `source_ref` exactly equal
to a path listed in that case's evaluator bundle documents, normally
`source/card.json`, `source/common_info.html`, or `source/documents.html`.
Do not infer missing facts. Keep quotes short. Return one label per case.
